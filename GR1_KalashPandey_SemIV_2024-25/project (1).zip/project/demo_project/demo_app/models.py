# Create your models here.
from django.db import models
from django.contrib.auth.hashers import make_password, check_password



class Profile(models.Model):
    id=models.AutoField(primary_key=True)
    username = models.CharField(max_length=100, unique=True)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    profile = models.ImageField(upload_to='profile_pics/',null=True)
    created_at = models.DateTimeField(auto_now_add=True)  # automatically set when the profile is created
    updated_at = models.DateTimeField(auto_now=True)  # automatically set to current time on every save

    def __str__(self):
        return self.username


    
class Result(models.Model):
    test_name=models.CharField(max_length=50)
    test_summary=models.CharField(max_length=500)
    test_result=models.ImageField(upload_to='result_img/')
    
class register(models.Model):
    id=models.AutoField(primary_key=True)
    username=models.CharField(max_length=50)
    email=models.EmailField(unique=True)
    password=models.CharField(max_length=250)
  
    def __str__(self):
        return self.username
    

    # This method hashes the password before saving
    def set_password(self, password):
        self.password = make_password(password)

    # This method checks the password using the hashed value
    def check_password(self, password):
        return check_password(password, self.password)
# from django.shortcuts import render

# Create your views here.
from contextvars import Token
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from demo_app.serializers import registerSerializer,LoginSerializer
from .models import register
from rest_framework import generics
from rest_framework.authtoken.models import Token
from django.contrib.auth.hashers import check_password
# Replace with the correct import path for your 'register' model
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken

from .serializers import LoginSerializer  # Assuming this serializer is correct
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required


def homepage(request):
    return render(request,'home.html')
def schedule(request):
    return render(request,'schedule.html')
def testresult(request):
    return render(request,'main.html')

def login_view(request):
   return render(request, 'login.html')
# Custom authenticate function
def authenticate_user_by_email(email, password):
    try:
        user = register.objects.get(email=email)
        
        if user.check_password(password): 
            return user
        return None
    except User.DoesNotExist:
       
        return None

@api_view(['POST'])
def login_api(request):
    if request.method == 'POST':
        # Use the LoginSerializer to validate the incoming data
        serializer = LoginSerializer(data=request.data)
        
        if serializer.is_valid():
            email = serializer.validated_data['email']
            password = serializer.validated_data['password']

            # Authenticate the user
            user = authenticate_user_by_email(email, password)

            if user is not None:
                # If the user is authenticated, generate JWT tokens
                refresh = RefreshToken.for_user(user)
                access_token = str(refresh.access_token)
                refresh_token = str(refresh)

                # Optionally, you can store the token in the session
                request.session['access_token'] = access_token
                
                # Redirect the user to their profile after successful login
                return redirect('home')  # Assuming 'profile' is your profile page's URL name
            
            else:
                # If authentication fails, render the login form with an error message
                return render(request, 'login.html', {'error': 'Invalid credentials. Please try again.'})
        
        # If serializer is invalid, return errors
        return render(request, 'login.html', {'error': 'Invalid data. Please check your input.'})

    return render(request, 'login.html', {'error': None})



from django.shortcuts import redirect, render

def register_view(request):
   
    return render(request, 'register.html', {'error': None})

@api_view(['POST'])
def manage_register(request):
    if request.method=='POST':
        serializer=registerSerializer(data=request.data)  #storing,mapping the data in the variable and then checking it 
        if serializer.is_valid():
            serializer.save()
            return redirect('login')
            # return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
              return render(request, 'register.html', {'error': serializer.errors})
    
    return render(request, 'register.html', {'error': None})



   


# @login_required 
# def manage_profile(request):
#    
#     user = request.user
    
#     if request.method == 'POST':
#         # Update profile if necessary
#         # You can use a form or serializer to update the user profile
#         # Example:
#         user.first_name = request.POST.get('first_name')
#         user.last_name = request.POST.get('last_name')
#         user.save()
#         return redirect('profile')  # Redirect to profile page after saving
        
#     return render(request, 'profile.html', {'user': user})

# def manage_profile_api(request):
#     # Ensure the user is authenticated
#     if not request.user.is_authenticated:
#         return Response({"error": "Unauthorized"}, status=401)
    
#     user = request.user

#     # Handle GET request - return the user's profile data
#     if request.method == 'GET':
#         serializer = ProfileSerializer(user)
#         return Response(serializer.data)
    
#     # Handle PUT request - update the user's profile data
#     if request.method == 'PUT':
#         serializer = ProfileSerializer(user, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         return Response(serializer.errors, status=400)
# @login_required
# @api_view(['POST', 'GET'])
# def manage_profile(request):
#     if request.method=='POST':
#         serialiserData = create_profile(request) #createNewProfile
#         if (serialiserData == "ERROR"):
#             return Response(serializers.errors, status=status.HTTP_400_BAD_REQUEST)
#         else:
#             return Response(serializers.data, status=status.HTTP_201_CREATED)
#         # serialiser= ProfileSerializer(data=request.data)
#         # if serialiser.is_valid():
#         #     serialiser.save()
#         #     return Response(serialiser.data, status=status.HTTP_201_CREATED)  # Return the newly created profile
#         # return Response(serialiser.errors, status=status.HTTP_400_BAD_REQUEST)
#     elif request.method=='GET':
#         serialiserData = get_profile(request)
#         return serialiserData
#     #     profiles=Profile.objects.all()
#     # serialiser=ProfileSerializer(profiles,many=True) 
#     # return Response(serialiser.data)

# def create_profile(request):
#     serializer= ProfileSerializer(data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#         return serializer.data
#     else:
#         return "ERROR" 
    
# def get_profile(request):
#     profiles=Profile.objects.all()
#     serialiser=ProfileSerializer(profiles,many=True) 
#     return Response(serialiser.data)



 #updating and searching with a name

# class LoginApi(APIView):
#     def post(self, request):
#         try:
#             data = request.data
#             # Use the LoginSerializer to validate incoming data
#             serializer = LoginSerializer(data=data)

#             # Validate serializer
#             if serializer.is_valid():
#                 email = serializer.validated_data['email']
#                 password = serializer.validated_data['password']

#                 # Authenticate the user using the custom authenticate function
#                 user = authenticate_user_by_email(email, password)

#                 if user is None:
#                     return Response({
#                         'status': 400,
#                         'message': 'INVALID CREDENTIALS',
#                         'data': {}
#                     }, status=400)

#                 # Generate JWT tokens for the authenticated user
#                 refresh = RefreshToken.for_user(user)
#                 access_token = str(refresh.access_token)
#                 refresh_token = str(refresh)

#                 return Response({
#                     'status': 200,
#                     'message': 'Login successful',
#                     'data': {
#                         'access': access_token,
#                         'refresh': refresh_token
#                     }
#                 }, status=200)

#             # If serializer is invalid, return the validation errors
#             return Response({
#                 'status': 400,
#                 'message': 'Invalid data',
#                 'data': serializer.errors
#             }, status=400)

#         except Exception as e:
#             print(f"Error: {str(e)}")
#             return Response({
#                 'status': 500, 
#                 'message': f'An error occurred: {str(e)}',
#                 'data': {}
#             }, status=500)





            # return Response(serializer.data, status=status.HTTP_400_BAD_REQUEST)
    # elif request.method=='GET':
    #     registers=register.objects.all() #
    #     s2=registerSerializer(registers,many=True)
    #     return Response(s2.data)




from django.urls import path
from . import views
from demo_app.views import *

urlpatterns = [


    path('register',views.register_view,name="register"),
    path('login',views.login_view,name="login"),
    path('registerAPI', views.manage_register, name='register_api'), 
    path('loginAPI', views.login_api, name='login_api'),
    path('home',views.homepage,name='home'),
    path('testresult',views.testresult,name="testresult"),
    path('schedule',views.schedule,name="schedule")
   # if using class-based view
]
